﻿Public Class Form1
    Public con As OleDb.OleDbConnection = New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\admin\Documents\Visual Studio 2010\Projects\result\Result.mdb")
    Public cmd As OleDb.OleDbDataAdapter
    Public cmd1 As OleDb.OleDbCommand
    Public ds As DataSet = New DataSet()
    Public dt As DataTable = New DataTable()
    Dim a As Integer = 15
    

    Private Sub LinkLabel1_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Dim a As Integer
        a = 4
        Dim tb As New TextBox
        tb.Name = "TextBox" + a.ToString

        TextBox1.Location = New Point(30, a * 30)
        Me.Controls.Add(tb)
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim constring As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\admin\Documents\Database1.accdb"
            Using con As New OleDb.OleDbConnection(constring)
                Using cmd As New OleDb.OleDbCommand("INSERT INTO test VALUES(@id, @sname)", con)
                    cmd.Parameters.AddWithValue("@id", row.Cells("id").Value)
                    cmd.Parameters.AddWithValue("@sname", row.Cells("sname").Value)
                    con.Open()
                    cmd.ExecuteNonQuery()
                    con.Close()

                End Using
            End Using
        Next
        MessageBox.Show("Records inserted.")
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        TextBox1.Text = a
        a = a - 1
        If a = 0 Then
            Timer1.Stop() 'Timer stops functioning
            MsgBox("Timer Stopped....")
        End If

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Form2.Show()
    End Sub
End Class
