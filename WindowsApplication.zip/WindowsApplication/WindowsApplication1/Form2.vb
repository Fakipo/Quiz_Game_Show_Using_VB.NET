﻿Public Class Form2
    Public con As OleDb.OleDbConnection = New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Kalpana\Documents\result.mdb")
    Public da As OleDb.OleDbDataAdapter
    Public cmd As OleDb.OleDbCommand
    Public dr As OleDb.OleDbDataReader
    Public ds As DataSet = New DataSet()
    Public dt As DataTable = New DataTable()
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        cmd = New OleDb.OleDbCommand("select id,sname from test where id = 1", con)
        con.Open()
        Dim dr As OleDb.OleDbDataReader
        dr = cmd.ExecuteReader()
        If (dr.HasRows) Then
            While (dr.Read())
                Label1.Text = dr("id").ToString()
                Label2.Text = dr("sname").ToString()
            End While
        End If
        con.Close()
        'da = New OleDb.OleDbDataAdapter("select * from test", con)
        'da.Fill(ds, "test")
        'Label1.DataBindings.Add("text", ds, "test.id")
        'Label2.DataBindings.Add("text", ds, "test.sname")
    End Sub
End Class