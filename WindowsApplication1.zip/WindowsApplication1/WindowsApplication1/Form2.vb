﻿Public Class Form2
    Public con As OleDb.OleDbConnection = New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\admin\Documents\result.mdb")
    Public da As OleDb.OleDbDataAdapter
    Public cmd As OleDb.OleDbCommand
    Public dr As OleDb.OleDbDataReader
    Public ds As DataSet = New DataSet()
    Public dt As DataTable = New DataTable()
    Dim a As Integer

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        a = a + 1
        cmd = New OleDb.OleDbCommand("select id,sname from tab where id= " & a & " ", con)
        con.Open()
        Dim dr As OleDb.OleDbDataReader
        dr = cmd.ExecuteReader()
        If (dr.HasRows) Then
            While (dr.Read())
                Label1.Text = dr("id").ToString()
                Label2.Text = dr("sname").ToString()
            End While
        Else
            MsgBox("lastdata")
        End If
        dr.Close()
        con.Close()
    End Sub

    Private Sub Form2_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        da = New OleDb.OleDbDataAdapter("select min(id) from tab", con)
        da.Fill(ds, "tab")
        a = Convert.ToInt16(ds.Tables(0).Rows(0).Item(0))
        cmd = New OleDb.OleDbCommand("select id,sname from tab where id= " & a & " ", con)
        con.Open()
        Dim dr As OleDb.OleDbDataReader
        dr = cmd.ExecuteReader()
        If (dr.HasRows) Then
            While (dr.Read())
                Label1.Text = dr("id").ToString()
                Label2.Text = dr("sname").ToString()

            End While
        End If
        dr.Close()

        con.Close()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        a = a - 1
        cmd = New OleDb.OleDbCommand("select id,sname from tab where id= " & a & " ", con)
        con.Open()
        Dim dr As OleDb.OleDbDataReader
        dr = cmd.ExecuteReader()
        If (dr.HasRows) Then
            While (dr.Read())
                Label1.Text = dr("id").ToString()
                Label2.Text = dr("sname").ToString()
            End While
        Else
            MsgBox("firstdata")
        End If
        dr.Close()
        con.Close()
    End Sub
End Class